package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.security.configureAppCheck
import com.example.domain.model.HudTab
import com.example.ui.components.TelemetryHudHeader
import com.example.ui.screens.HudCoreScreen
import com.example.ui.screens.ModulesScreen
import com.example.ui.screens.SystemsScreen
import com.example.ui.theme.JarvisTheme
import com.example.ui.viewmodel.JarvisHudViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch intent before any UI or ViewModels
        configureAppCheck(this, intent)

        // STEP 2: Enable Edge-to-Edge HUD rendering
        enableEdgeToEdge()

        setContent {
            JarvisTheme {
                JarvisApp()
            }
        }
    }
}

@Composable
fun JarvisApp(
    viewModel: JarvisHudViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val hudColors = JarvisTheme.hudColors

    // Ensure system back from secondary tabs returns cleanly to HUD Core
    BackHandler(enabled = uiState.selectedTab != HudTab.HUD_CORE) {
        viewModel.selectTab(HudTab.HUD_CORE)
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        hudColors.voidBackground,
                        hudColors.panelSurface.copy(alpha = 0.55f),
                        hudColors.voidBackground
                    )
                )
            )
    ) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = hudColors.voidBackground.copy(alpha = 0f),
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = hudColors.panelSurface.copy(alpha = 0.96f),
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        HudTab.entries.forEach { tab ->
                            val selected = uiState.selectedTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, selected),
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = hudColors.cyanGlow,
                                    selectedTextColor = hudColors.cyanGlow,
                                    indicatorColor = hudColors.cyanGlow.copy(alpha = 0.16f),
                                    unselectedIconColor = hudColors.slateText,
                                    unselectedTextColor = hudColors.slateText
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(
                        containerColor = hudColors.panelSurface.copy(alpha = 0.96f),
                        modifier = Modifier
                            .fillMaxHeight()
                            .statusBarsPadding()
                    ) {
                        HudTab.entries.forEach { tab ->
                            val selected = uiState.selectedTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, selected),
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = hudColors.cyanGlow,
                                    selectedTextColor = hudColors.cyanGlow,
                                    indicatorColor = hudColors.cyanGlow.copy(alpha = 0.16f),
                                    unselectedIconColor = hudColors.slateText,
                                    unselectedTextColor = hudColors.slateText
                                ),
                                modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .imePadding(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 760.dp)
                    ) {
                        TelemetryHudHeader(
                            status = uiState.assistantStatus,
                            telemetry = uiState.telemetry,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                        )

                        when (uiState.selectedTab) {
                            HudTab.HUD_CORE -> HudCoreScreen(
                                uiState = uiState,
                                onOrbClick = viewModel::toggleListeningPreview,
                                onSelectStatus = viewModel::setAssistantStatus,
                                onInputChange = viewModel::updateInputDraft,
                                onSendCommand = viewModel::submitCommand,
                                modifier = Modifier.weight(1f)
                            )

                            HudTab.MODULES -> ModulesScreen(
                                uiState = uiState,
                                onModuleClick = viewModel::openModuleDetails,
                                onDismissModule = viewModel::dismissModuleDetails,
                                modifier = Modifier.weight(1f)
                            )

                            HudTab.SYSTEMS -> SystemsScreen(
                                uiState = uiState,
                                onRefreshDiagnostics = viewModel::refreshDiagnostics,
                                onRequestClearHistory = { viewModel.requestClearHistoryDialog(true) },
                                onConfirmClearHistory = viewModel::clearConsoleHistory,
                                onDismissClearDialog = { viewModel.requestClearHistoryDialog(false) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun tabIcon(tab: HudTab, selected: Boolean): ImageVector = when (tab) {
    HudTab.HUD_CORE -> if (selected) Icons.Filled.Hub else Icons.Outlined.Hub
    HudTab.MODULES -> if (selected) Icons.Filled.Dashboard else Icons.Outlined.Dashboard
    HudTab.SYSTEMS -> if (selected) Icons.Filled.Security else Icons.Outlined.Security
}
