package com.example.core.security

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.domain.model.PermissionAuditItem

class PermissionInspector(private val context: Context) {

    fun inspectAll(): List<PermissionAuditItem> {
        val micGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val notifPostGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val notificationListenerEnabled = NotificationManagerCompat
            .getEnabledListenerPackages(context)
            .contains(context.packageName)

        val accessibilityEnabled = isAccessibilityServiceEnabled()
        val canWriteSystemSettings = Settings.System.canWrite(context)

        return listOf(
            PermissionAuditItem(
                id = "telemetry",
                title = "Device & Battery Telemetry",
                stageLabel = "Stage 1 (Active)",
                isGranted = true,
                whyRequired = "Uses standard Android BatteryManager & ActivityManager broadcasts with zero sensitive permissions.",
                permissionKey = "Standard System Broadcasts"
            ),
            PermissionAuditItem(
                id = "mic",
                title = "Microphone (SpeechRecognizer)",
                stageLabel = "Stage 3",
                isGranted = micGranted,
                whyRequired = "Needed only when you tap the mic or enable voice conversation. Never records silently.",
                permissionKey = "android.permission.RECORD_AUDIO"
            ),
            PermissionAuditItem(
                id = "write_settings",
                title = "System Brightness Control",
                stageLabel = "Stage 4",
                isGranted = canWriteSystemSettings,
                whyRequired = "Allows JARVIS to adjust screen brightness when explicitly requested.",
                permissionKey = "Settings.ACTION_MANAGE_WRITE_SETTINGS"
            ),
            PermissionAuditItem(
                id = "accessibility",
                title = "Accessibility UI Assistance",
                stageLabel = "Stage 5",
                isGranted = accessibilityEnabled,
                whyRequired = "Enables explicitly authorized UI navigation & actions without bypassing Android security.",
                permissionKey = "AccessibilityService (Opt-In)"
            ),
            PermissionAuditItem(
                id = "post_notif",
                title = "Smart Reminder Alerts",
                stageLabel = "Stage 6",
                isGranted = notifPostGranted,
                whyRequired = "Delivers scheduled reminders and daily briefing notifications.",
                permissionKey = "android.permission.POST_NOTIFICATIONS"
            ),
            PermissionAuditItem(
                id = "notif_listener",
                title = "Notification Listener Access",
                stageLabel = "Stage 6",
                isGranted = notificationListenerEnabled,
                whyRequired = "Reads incoming notifications only when you explicitly grant access for summaries.",
                permissionKey = "NotificationListenerService (Opt-In)"
            )
        )
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        return enabledServices.split(':').any { component ->
            component.contains(context.packageName, ignoreCase = true)
        }
    }
}
