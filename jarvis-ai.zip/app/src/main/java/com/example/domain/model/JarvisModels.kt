package com.example.domain.model

enum class AssistantStatus(val label: String, val detail: String) {
    IDLE("STANDBY ONLINE", "HUD Core active • Ready for command"),
    LISTENING("LISTENING", "Voice waveform HUD visualizer active"),
    THINKING("ANALYZING", "Neural telemetry & context routing"),
    SPEAKING("RESPONDING", "Synthesizing natural Hinglish/EN output"),
    OFFLINE_GUARD("LOCAL MODE", "Device telemetry & HUD operating locally")
}

enum class HudTab(val label: String) {
    HUD_CORE("HUD Core"),
    MODULES("Modules"),
    SYSTEMS("Systems")
}

enum class MessageSender {
    USER,
    JARVIS,
    SYSTEM
}

data class HudMessage(
    val id: String,
    val sender: MessageSender,
    val text: String,
    val timestampLabel: String,
    val tag: String? = null
)

data class DeviceTelemetry(
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val chargeSource: String = "Battery",
    val batteryTempCelsius: Float = 0f,
    val deviceName: String = "Android Device",
    val androidVersion: String = "",
    val sdkInt: Int = 0,
    val availableRamGb: Float = 0f,
    val totalRamGb: Float = 0f
)

enum class ModuleStageStatus(val badgeText: String) {
    ACTIVE_STAGE_1("ACTIVE • STAGE 1"),
    NEXT_STAGE_2("NEXT • STAGE 2"),
    ROADMAP("PLANNED")
}

data class JarvisModuleInfo(
    val id: Int,
    val name: String,
    val stageLabel: String,
    val status: ModuleStageStatus,
    val summary: String,
    val androidApis: String,
    val permissionNote: String
)

data class PermissionAuditItem(
    val id: String,
    val title: String,
    val stageLabel: String,
    val isGranted: Boolean,
    val whyRequired: String,
    val permissionKey: String
)

data class QuickCommandPreset(
    val label: String,
    val promptText: String
)

object JarvisModuleCatalog {
    val modules: List<JarvisModuleInfo> = listOf(
        JarvisModuleInfo(
            id = 1,
            name = "Personal Assistant",
            stageLabel = "Stage 1–2",
            status = ModuleStageStatus.ACTIVE_STAGE_1,
            summary = "Core HUD personality, friendly English + Hinglish interaction, and proactive daily companion.",
            androidApis = "Jetpack Compose HUD, Firebase AI Logic",
            permissionNote = "No special permissions required for text cockpit."
        ),
        JarvisModuleInfo(
            id = 2,
            name = "Voice Chat",
            stageLabel = "Stage 3",
            status = ModuleStageStatus.ROADMAP,
            summary = "Hands-free speech-to-text & natural text-to-speech in Hindi and English with configurable wake-word trigger.",
            androidApis = "SpeechRecognizer, TextToSpeech, ForegroundService",
            permissionNote = "Requires RECORD_AUDIO only when user activates voice."
        ),
        JarvisModuleInfo(
            id = 3,
            name = "Phone Controller",
            stageLabel = "Stage 4",
            status = ModuleStageStatus.ROADMAP,
            summary = "Adjust screen brightness where permitted, control media playback, set alarms/timers, and share text.",
            androidApis = "AlarmClock Intents, MediaSession, Settings.System",
            permissionNote = "Uses official Android Intents and optional WRITE_SETTINGS."
        ),
        JarvisModuleInfo(
            id = 4,
            name = "Smart Reminder",
            stageLabel = "Stage 6",
            status = ModuleStageStatus.ROADMAP,
            summary = "Natural-language reminder scheduling with reliable local alarms and interactive notification actions.",
            androidApis = "WorkManager, AlarmManager, NotificationCompat",
            permissionNote = "Requires POST_NOTIFICATIONS on Android 13+."
        ),
        JarvisModuleInfo(
            id = 5,
            name = "Daily Planner",
            stageLabel = "Stage 2 & 6",
            status = ModuleStageStatus.ROADMAP,
            summary = "Morning briefings, time-blocked schedules, and practical prioritization tailored to your day.",
            androidApis = "Firebase AI Logic Structured Output, Room",
            permissionNote = "Stored privately on-device with full user control."
        ),
        JarvisModuleInfo(
            id = 6,
            name = "AI Advisor",
            stageLabel = "Stage 2",
            status = ModuleStageStatus.NEXT_STAGE_2,
            summary = "Gemini-powered reasoning for study, coding, productivity coaching, and everyday problem-solving.",
            androidApis = "Firebase AI Logic (gemini-3.8-flash), App Check",
            permissionNote = "Protected by Firebase App Check; zero client API keys."
        ),
        JarvisModuleInfo(
            id = 7,
            name = "Notification Assistant",
            stageLabel = "Stage 6",
            status = ModuleStageStatus.ROADMAP,
            summary = "Reads and summarizes incoming notifications only after explicit user-granted Notification Access.",
            androidApis = "NotificationListenerService",
            permissionNote = "Opt-in via Android Notification Access settings."
        ),
        JarvisModuleInfo(
            id = 8,
            name = "Battery Monitor",
            stageLabel = "Stage 1",
            status = ModuleStageStatus.ACTIVE_STAGE_1,
            summary = "Live device battery level, charging source, thermal state, RAM telemetry, and OS hardware diagnostics.",
            androidApis = "BatteryManager, ActivityManager, Build",
            permissionNote = "Zero dangerous permissions required."
        ),
        JarvisModuleInfo(
            id = 9,
            name = "App Launcher",
            stageLabel = "Stage 4",
            status = ModuleStageStatus.ROADMAP,
            summary = "Launches installed apps, system settings, camera, gallery, and websites using verified Android Intents.",
            androidApis = "PackageManager (<queries>), Intent.ACTION_VIEW",
            permissionNote = "Uses scoped <queries> declarations; verifies launch result."
        ),
        JarvisModuleInfo(
            id = 10,
            name = "Conversation Memory",
            stageLabel = "Stage 7",
            status = ModuleStageStatus.ROADMAP,
            summary = "Remembers user-approved preferences and conversation context locally with instant one-tap wipe.",
            androidApis = "Room Database (KSP), Jetpack DataStore",
            permissionNote = "100% local encrypted-ready preferences & history clear."
        )
    )

    val quickCommands: List<QuickCommandPreset> = listOf(
        QuickCommandPreset("System Status", "System status and battery report"),
        QuickCommandPreset("Hinglish Greeting", "Hey Jarvis, kya haal hai? Ready ho?"),
        QuickCommandPreset("Device Specs", "Show my phone hardware & RAM telemetry"),
        QuickCommandPreset("Stage Roadmap", "What features unlock in Stage 2?")
    )
}
