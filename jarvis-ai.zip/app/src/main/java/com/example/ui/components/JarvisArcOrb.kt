package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.AssistantStatus
import com.example.ui.theme.JarvisTheme
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisArcOrb(
    status: AssistantStatus,
    onOrbClick: () -> Unit,
    modifier: Modifier = Modifier,
    orbSize: Dp = 188.dp
) {
    val hudColors = JarvisTheme.hudColors

    val primaryAccent by animateColorAsState(
        targetValue = when (status) {
            AssistantStatus.IDLE -> hudColors.cyanGlow
            AssistantStatus.LISTENING -> hudColors.tealPulse
            AssistantStatus.THINKING -> hudColors.amberAlert
            AssistantStatus.SPEAKING -> hudColors.cyanGlow
            AssistantStatus.OFFLINE_GUARD -> hudColors.blueGlow
        },
        animationSpec = tween(durationMillis = 320),
        label = "orbPrimaryAccent"
    )

    val secondaryAccent by animateColorAsState(
        targetValue = when (status) {
            AssistantStatus.IDLE -> hudColors.blueGlow
            AssistantStatus.LISTENING -> hudColors.cyanGlow
            AssistantStatus.THINKING -> hudColors.blueGlow
            AssistantStatus.SPEAKING -> hudColors.emeraldOnline
            AssistantStatus.OFFLINE_GUARD -> hudColors.hudBorder
        },
        animationSpec = tween(durationMillis = 320),
        label = "orbSecondaryAccent"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "jarvisOrbLoop")
    val outerAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (status == AssistantStatus.THINKING) 3600 else 11000,
                easing = LinearEasing
            )
        ),
        label = "outerAngle"
    )

    val innerAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (status == AssistantStatus.LISTENING) 4200 else 8000,
                easing = LinearEasing
            )
        ),
        label = "innerAngle"
    )

    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (status) {
                    AssistantStatus.LISTENING -> 650
                    AssistantStatus.SPEAKING -> 520
                    AssistantStatus.THINKING -> 750
                    else -> 1800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseProgress"
    )

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing)
        ),
        label = "wavePhase"
    )

    val activityIntensity by animateFloatAsState(
        targetValue = when (status) {
            AssistantStatus.LISTENING, AssistantStatus.SPEAKING -> 1f
            AssistantStatus.THINKING -> 0.72f
            AssistantStatus.IDLE -> 0.25f
            AssistantStatus.OFFLINE_GUARD -> 0.15f
        },
        animationSpec = tween(durationMillis = 280),
        label = "activityIntensity"
    )

    Box(
        modifier = modifier.size(orbSize),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(orbSize)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f

            // Ambient radial glow behind the arc core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryAccent.copy(alpha = 0.28f * pulseProgress),
                        secondaryAccent.copy(alpha = 0.12f),
                        hudColors.voidBackground.copy(alpha = 0f)
                    ),
                    center = center,
                    radius = maxRadius
                ),
                radius = maxRadius,
                center = center
            )

            // Outer calibrated telemetry ring
            val outerRingRadius = maxRadius * 0.88f
            drawCircle(
                color = primaryAccent.copy(alpha = 0.18f),
                radius = outerRingRadius,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Rotating segmented outer arcs
            rotate(degrees = outerAngle, pivot = center) {
                val arcRectTopLeft = Offset(
                    center.x - outerRingRadius,
                    center.y - outerRingRadius
                )
                val arcRectSize = Size(outerRingRadius * 2f, outerRingRadius * 2f)
                val sweeps = listOf(0f to 58f, 90f to 42f, 180f to 64f, 270f to 44f)
                sweeps.forEach { (start, sweep) ->
                    drawArc(
                        color = primaryAccent.copy(alpha = 0.85f),
                        startAngle = start,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = arcRectTopLeft,
                        size = arcRectSize,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // Counter-rotating mid reactor ring
            val midRingRadius = maxRadius * 0.70f
            rotate(degrees = innerAngle, pivot = center) {
                val arcTopLeft = Offset(center.x - midRingRadius, center.y - midRingRadius)
                val arcSize = Size(midRingRadius * 2f, midRingRadius * 2f)
                for (i in 0 until 6) {
                    drawArc(
                        color = secondaryAccent.copy(alpha = if (i % 2 == 0) 0.9f else 0.45f),
                        startAngle = i * 60f + 8f,
                        sweepAngle = 36f,
                        useCenter = false,
                        topLeft = arcTopLeft,
                        size = arcSize,
                        style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // Harmonic waveform ticks around the perimeter (amplifies during Listening/Speaking)
            val tickCount = 36
            val tickBaseRadius = maxRadius * 0.76f
            for (i in 0 until tickCount) {
                val angleRad = (i * (360f / tickCount)) * (PI / 180.0)
                val waveAmp = (sin(wavePhase + i * 0.55f) + 1f) * 0.5f
                val tickLength = (3.dp.toPx() + 9.dp.toPx() * waveAmp * activityIntensity)
                val startR = tickBaseRadius - tickLength * 0.35f
                val endR = tickBaseRadius + tickLength * 0.65f
                val start = Offset(
                    x = center.x + (cos(angleRad) * startR).toFloat(),
                    y = center.y + (sin(angleRad) * startR).toFloat()
                )
                val end = Offset(
                    x = center.x + (cos(angleRad) * endR).toFloat(),
                    y = center.y + (sin(angleRad) * endR).toFloat()
                )
                drawLine(
                    color = primaryAccent.copy(alpha = 0.35f + 0.5f * activityIntensity * waveAmp),
                    start = start,
                    end = end,
                    strokeWidth = 1.8.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Inner glowing energy halo
            val coreRingRadius = maxRadius * 0.48f * pulseProgress.coerceAtMost(1.03f)
            drawCircle(
                color = primaryAccent.copy(alpha = 0.55f),
                radius = coreRingRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Interactive center mic/orb core button (minimum 48dp+ touch target)
        val interactionSource = remember { MutableInteractionSource() }
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryAccent.copy(alpha = 0.28f),
                            hudColors.panelSurface
                        )
                    )
                )
                .border(1.5.dp, primaryAccent.copy(alpha = 0.85f), CircleShape)
                .clickable(
                    interactionSource = interactionSource,
                    indication = ripple(bounded = true, color = primaryAccent),
                    onClick = onOrbClick
                )
                .testTag("orb_mic_button"),
            contentAlignment = Alignment.Center
        ) {
            val coreIcon = when (status) {
                AssistantStatus.LISTENING -> Icons.Filled.GraphicEq
                AssistantStatus.THINKING -> Icons.Filled.Psychology
                AssistantStatus.SPEAKING -> Icons.Filled.RecordVoiceOver
                else -> Icons.Filled.Mic
            }
            Icon(
                imageVector = coreIcon,
                contentDescription = stringResource(R.string.orb_mic_cd),
                tint = primaryAccent,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}
