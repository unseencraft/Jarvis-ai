package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.AssistantStatus
import com.example.domain.model.HudMessage
import com.example.domain.model.JarvisModuleCatalog
import com.example.domain.model.MessageSender
import com.example.ui.components.JarvisArcOrb
import com.example.ui.theme.JarvisTheme
import com.example.ui.viewmodel.JarvisHudUiState

@Composable
fun HudCoreScreen(
    uiState: JarvisHudUiState,
    onOrbClick: () -> Unit,
    onSelectStatus: (AssistantStatus) -> Unit,
    onInputChange: (String) -> Unit,
    onSendCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val hudColors = JarvisTheme.hudColors
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.lastIndex)
        }
    }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Futuristic AI Core Visualization Stage
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            JarvisArcOrb(
                status = uiState.assistantStatus,
                onOrbClick = onOrbClick,
                orbSize = 172.dp
            )

            Text(
                text = uiState.assistantStatus.detail,
                style = MaterialTheme.typography.labelMedium,
                color = hudColors.slateText,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Interactive HUD State Preview Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                val previewStates = listOf(
                    AssistantStatus.IDLE to "Idle",
                    AssistantStatus.LISTENING to "Listening",
                    AssistantStatus.THINKING to "Thinking",
                    AssistantStatus.SPEAKING to "Speaking"
                )
                previewStates.forEach { (state, label) ->
                    val selected = uiState.assistantStatus == state
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectStatus(state) },
                        label = {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = hudColors.panelSurface,
                            labelColor = hudColors.slateText,
                            selectedContainerColor = hudColors.cyanGlow.copy(alpha = 0.2f),
                            selectedLabelColor = hudColors.cyanGlow
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = hudColors.hudBorder.copy(alpha = 0.55f),
                            selectedBorderColor = hudColors.cyanGlow
                        ),
                        modifier = Modifier.testTag("status_chip_${label.lowercase()}")
                    )
                }
            }
        }

        // Conversational HUD Feed
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(uiState.messages, key = { it.id }) { message ->
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn() + slideInVertically { it / 3 }
                ) {
                    HudMessageBubble(message = message)
                }
            }
        }

        // Quick Hinglish & Telemetry Command Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            JarvisModuleCatalog.quickCommands.forEachIndexed { index, preset ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = hudColors.panelElevated,
                    modifier = Modifier
                        .sizeIn(minHeight = 40.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .border(
                            1.dp,
                            hudColors.hudBorder.copy(alpha = 0.7f),
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { onSendCommand(preset.promptText) }
                        .testTag("quick_cmd_$index")
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = preset.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = hudColors.cyanGlow,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Bottom HUD Text Composer + Voice Visualizer Trigger
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(18.dp),
            color = hudColors.panelSurface
        ) {
            Row(
                modifier = Modifier
                    .border(
                        1.dp,
                        hudColors.hudBorder.copy(alpha = 0.85f),
                        RoundedCornerShape(18.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOrbClick,
                    modifier = Modifier
                        .sizeIn(minWidth = 48.dp, minHeight = 48.dp)
                        .clip(CircleShape)
                        .background(
                            if (uiState.assistantStatus == AssistantStatus.LISTENING) {
                                hudColors.tealPulse.copy(alpha = 0.2f)
                            } else {
                                hudColors.panelElevated
                            }
                        )
                        .testTag("mic_toggle_button")
                ) {
                    Icon(
                        imageVector = if (uiState.assistantStatus == AssistantStatus.LISTENING) {
                            Icons.Filled.GraphicEq
                        } else {
                            Icons.Filled.Mic
                        },
                        contentDescription = stringResource(R.string.orb_mic_cd),
                        tint = hudColors.cyanGlow
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                OutlinedTextField(
                    value = uiState.inputDraft,
                    onValueChange = onInputChange,
                    placeholder = {
                        Text(
                            text = stringResource(R.string.input_placeholder),
                            style = MaterialTheme.typography.bodyMedium,
                            color = hudColors.slateText.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = { onSendCommand(uiState.inputDraft) }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = hudColors.cyanGlow.copy(alpha = 0f),
                        unfocusedBorderColor = hudColors.cyanGlow.copy(alpha = 0f),
                        cursorColor = hudColors.cyanGlow
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field")
                )

                IconButton(
                    onClick = { onSendCommand(uiState.inputDraft) },
                    enabled = uiState.inputDraft.isNotBlank(),
                    modifier = Modifier
                        .sizeIn(minWidth = 48.dp, minHeight = 48.dp)
                        .clip(CircleShape)
                        .background(
                            brush = if (uiState.inputDraft.isNotBlank()) {
                                Brush.linearGradient(
                                    listOf(hudColors.cyanGlow, hudColors.blueGlow)
                                )
                            } else {
                                Brush.linearGradient(
                                    listOf(hudColors.panelElevated, hudColors.panelElevated)
                                )
                            }
                        )
                        .testTag("send_message_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.send_message_cd),
                        tint = if (uiState.inputDraft.isNotBlank()) {
                            hudColors.voidBackground
                        } else {
                            hudColors.slateText
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HudMessageBubble(
    message: HudMessage
) {
    val hudColors = JarvisTheme.hudColors

    when (message.sender) {
        MessageSender.SYSTEM -> {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(hudColors.panelSurface.copy(alpha = 0.7f))
                    .border(
                        1.dp,
                        hudColors.hudBorder.copy(alpha = 0.5f),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.labelMedium,
                        color = hudColors.cyanGlow,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = message.timestampLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = hudColors.slateText
                    )
                }
            }
        }

        MessageSender.USER -> {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 310.dp)
                        .clip(
                            RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 4.dp,
                                bottomStart = 16.dp,
                                bottomEnd = 16.dp
                            )
                        )
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    hudColors.blueGlow.copy(alpha = 0.38f),
                                    hudColors.panelElevated
                                )
                            )
                        )
                        .border(
                            1.dp,
                            hudColors.blueGlow.copy(alpha = 0.65f),
                            RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 4.dp,
                                bottomStart = 16.dp,
                                bottomEnd = 16.dp
                            )
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "YOU • ${message.timestampLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = hudColors.slateText,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }

        MessageSender.JARVIS -> {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 330.dp)
                        .clip(
                            RoundedCornerShape(
                                topStart = 4.dp,
                                topEnd = 16.dp,
                                bottomStart = 16.dp,
                                bottomEnd = 16.dp
                            )
                        )
                        .background(hudColors.panelSurface)
                        .border(
                            1.dp,
                            hudColors.cyanGlow.copy(alpha = 0.55f),
                            RoundedCornerShape(
                                topStart = 4.dp,
                                topEnd = 16.dp,
                                bottomStart = 16.dp,
                                bottomEnd = 16.dp
                            )
                        )
                        .padding(horizontal = 14.dp, vertical = 11.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(hudColors.cyanGlow)
                        )
                        Text(
                            text = message.tag ?: "JARVIS",
                            style = MaterialTheme.typography.labelSmall,
                            color = hudColors.cyanGlow
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(
                        text = message.timestampLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = hudColors.slateText
                    )
                }
            }
        }
    }
}
