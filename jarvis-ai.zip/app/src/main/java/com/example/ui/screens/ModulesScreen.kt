package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.DeviceTelemetry
import com.example.domain.model.JarvisModuleInfo
import com.example.domain.model.ModuleStageStatus
import com.example.ui.theme.JarvisTheme
import com.example.ui.viewmodel.JarvisHudUiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModulesScreen(
    uiState: JarvisHudUiState,
    onModuleClick: (JarvisModuleInfo) -> Unit,
    onDismissModule: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hudColors = JarvisTheme.hudColors

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Futuristic HUD Hero Architecture Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(156.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, hudColors.hudBorder, RoundedCornerShape(18.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_jarvis_core_banner_1794586594827),
                    contentDescription = "Jarvis holographic command center",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    hudColors.voidBackground.copy(alpha = 0.35f),
                                    hudColors.voidBackground.copy(alpha = 0.92f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "10-MODULE JARVIS ARCHITECTURE",
                        style = MaterialTheme.typography.labelMedium,
                        color = hudColors.cyanGlow
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Modular Clean Architecture",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Tap any subsystem to inspect target Android APIs and permission scope.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = hudColors.slateText
                    )
                }
            }
        }

        item {
            LiveTelemetryModuleCard(telemetry = uiState.telemetry)
        }

        items(uiState.modules, key = { it.id }) { module ->
            ModuleCard(
                module = module,
                onClick = { onModuleClick(module) }
            )
        }
    }

    val selected = uiState.selectedModule
    if (selected != null) {
        ModalBottomSheet(
            onDismissRequest = onDismissModule,
            containerColor = hudColors.panelSurface,
            contentColor = MaterialTheme.colorScheme.onBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "${selected.stageLabel.uppercase(Locale.getDefault())} • ${selected.status.badgeText}",
                    style = MaterialTheme.typography.labelLarge,
                    color = hudColors.cyanGlow
                )
                Text(
                    text = selected.name,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = selected.summary,
                    style = MaterialTheme.typography.bodyLarge,
                    color = hudColors.slateText
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = hudColors.panelElevated,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "ANDROID APIS & STACK",
                            style = MaterialTheme.typography.labelSmall,
                            color = hudColors.cyanGlow
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = selected.androidApis,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "SECURITY & PERMISSION MODEL",
                            style = MaterialTheme.typography.labelSmall,
                            color = hudColors.amberAlert
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = selected.permissionNote,
                            style = MaterialTheme.typography.bodyMedium,
                            color = hudColors.slateText
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveTelemetryModuleCard(telemetry: DeviceTelemetry) {
    val hudColors = JarvisTheme.hudColors
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, hudColors.emeraldOnline.copy(alpha = 0.55f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        color = hudColors.panelSurface
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE DEVICE TELEMETRY",
                    style = MaterialTheme.typography.labelLarge,
                    color = hudColors.emeraldOnline
                )
                Text(
                    text = "ACTIVE NOW",
                    style = MaterialTheme.typography.labelSmall,
                    color = hudColors.emeraldOnline
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryMetricItem(
                    label = "BATTERY",
                    value = "${telemetry.batteryPercent}% (${telemetry.chargeSource})",
                    modifier = Modifier.weight(1f)
                )
                TelemetryMetricItem(
                    label = "THERMAL",
                    value = String.format(Locale.getDefault(), "%.1f °C", telemetry.batteryTempCelsius),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryMetricItem(
                    label = "MEMORY",
                    value = String.format(
                        Locale.getDefault(),
                        "%.2f / %.2f GB free",
                        telemetry.availableRamGb,
                        telemetry.totalRamGb
                    ),
                    modifier = Modifier.weight(1f)
                )
                TelemetryMetricItem(
                    label = "DEVICE",
                    value = "${telemetry.deviceName} • API ${telemetry.sdkInt}",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun TelemetryMetricItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    val hudColors = JarvisTheme.hudColors
    Column(modifier = modifier.padding(end = 8.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = hudColors.slateText
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ModuleCard(
    module: JarvisModuleInfo,
    onClick: () -> Unit
) {
    val hudColors = JarvisTheme.hudColors
    val badgeColor = when (module.status) {
        ModuleStageStatus.ACTIVE_STAGE_1 -> hudColors.emeraldOnline
        ModuleStageStatus.NEXT_STAGE_2 -> hudColors.cyanGlow
        ModuleStageStatus.ROADMAP -> hudColors.slateText
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                hudColors.hudBorder.copy(alpha = 0.6f),
                RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .testTag("module_card_${module.id}"),
        shape = RoundedCornerShape(16.dp),
        color = hudColors.panelSurface
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(hudColors.panelElevated)
                    .border(
                        1.dp,
                        badgeColor.copy(alpha = 0.5f),
                        RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = moduleIcon(module.id),
                    contentDescription = module.name,
                    tint = badgeColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = module.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = module.stageLabel.uppercase(Locale.getDefault()),
                        style = MaterialTheme.typography.labelSmall,
                        color = badgeColor
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = module.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = hudColors.slateText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private fun moduleIcon(id: Int): ImageVector = when (id) {
    1 -> Icons.Filled.AutoAwesome
    2 -> Icons.Filled.RecordVoiceOver
    3 -> Icons.Filled.SettingsSuggest
    4 -> Icons.Filled.NotificationsActive
    5 -> Icons.Filled.CalendarMonth
    6 -> Icons.Filled.Memory
    7 -> Icons.Filled.NotificationsNone
    8 -> Icons.Filled.BatteryChargingFull
    9 -> Icons.Filled.Apps
    else -> Icons.Filled.PhoneAndroid
}
