package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.PermissionAuditItem
import com.example.ui.theme.JarvisTheme
import com.example.ui.viewmodel.JarvisHudUiState

@Composable
fun SystemsScreen(
    uiState: JarvisHudUiState,
    onRefreshDiagnostics: () -> Unit,
    onRequestClearHistory: () -> Unit,
    onConfirmClearHistory: () -> Unit,
    onDismissClearDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hudColors = JarvisTheme.hudColors

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        hudColors.cyanGlow.copy(alpha = 0.55f),
                        RoundedCornerShape(16.dp)
                    ),
                shape = RoundedCornerShape(16.dp),
                color = hudColors.panelSurface
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.VerifiedUser,
                            contentDescription = "Security manifesto",
                            tint = hudColors.cyanGlow,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ZERO-TRUST PRIVACY PROTOCOL",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Text(
                        text = "• Never secretly records microphone audio or reads notifications.\n" +
                            "• Sensitive actions (messages, deletion, system settings) always require explicit confirmation.\n" +
                            "• Gemini AI Logic uses Firebase App Check with zero client-side API keys.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = hudColors.slateText
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onRefreshDiagnostics,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = hudColors.cyanGlow,
                        contentColor = hudColors.voidBackground
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .sizeIn(minHeight = 48.dp)
                        .testTag("refresh_diagnostics_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.refresh_diagnostics_action),
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                OutlinedButton(
                    onClick = onRequestClearHistory,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = hudColors.crimsonWarn
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .sizeIn(minHeight = 48.dp)
                        .testTag("clear_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteSweep,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.clear_console_action),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }

        item {
            Text(
                text = "PERMISSION & SERVICE AUDIT",
                style = MaterialTheme.typography.labelLarge,
                color = hudColors.cyanGlow,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        items(uiState.permissionAudit, key = { it.id }) { item ->
            PermissionAuditCard(item = item)
        }
    }

    if (uiState.showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = onDismissClearDialog,
            containerColor = hudColors.panelSurface,
            titleContentColor = MaterialTheme.colorScheme.onBackground,
            textContentColor = hudColors.slateText,
            icon = {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = null,
                    tint = hudColors.crimsonWarn
                )
            },
            title = { Text("Clear HUD Console History?") },
            text = {
                Text("This will erase the current Stage 1 conversation messages from the HUD console.")
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirmClearHistory,
                    modifier = Modifier.testTag("confirm_clear_history_button")
                ) {
                    Text("Clear", color = hudColors.crimsonWarn)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissClearDialog) {
                    Text("Cancel", color = hudColors.cyanGlow)
                }
            }
        )
    }
}

@Composable
private fun PermissionAuditCard(item: PermissionAuditItem) {
    val hudColors = JarvisTheme.hudColors
    val statusColor = if (item.isGranted) hudColors.emeraldOnline else hudColors.amberAlert
    val statusText = if (item.isGranted) "ACTIVE" else "NOT REQUESTED"

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                hudColors.hudBorder.copy(alpha = 0.55f),
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        color = hudColors.panelSurface
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (item.isGranted) Icons.Filled.CheckCircle else Icons.Filled.Lock,
                        contentDescription = statusText,
                        tint = statusColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusColor.copy(alpha = 0.16f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "${item.stageLabel} • $statusText",
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor
                    )
                }
            }

            Text(
                text = item.whyRequired,
                style = MaterialTheme.typography.bodyMedium,
                color = hudColors.slateText
            )

            Text(
                text = item.permissionKey,
                style = MaterialTheme.typography.labelSmall,
                color = hudColors.cyanGlow.copy(alpha = 0.85f)
            )
        }
    }
}
