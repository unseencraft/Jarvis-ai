package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VoidBlack = Color(0xFF030812)
val HudObsidian = Color(0xFF06101F)
val HudPanelDark = Color(0xFF0B192E)
val HudPanelElevated = Color(0xFF112542)
val HudSurfaceBright = Color(0xFF173156)

val ArcCyan = Color(0xFF00E5FF)
val ArcCyanDim = Color(0xFF0097B2)
val ArcBlue = Color(0xFF2979FF)
val ArcTeal = Color(0xFF18FFFF)
val ArcElectricContainer = Color(0xFF0A2E4D)

val HudIceWhite = Color(0xFFEAF6FF)
val HudSlateText = Color(0xFF8DB4DA)
val HudMutedText = Color(0xFF5D7FA3)
val HudBorderCyan = Color(0xFF1B4B75)

val HudAmber = Color(0xFFFFB300)
val HudEmerald = Color(0xFF00E676)
val HudCrimson = Color(0xFFFF5252)
