package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class JarvisHudColors(
    val voidBackground: Color,
    val panelSurface: Color,
    val panelElevated: Color,
    val cyanGlow: Color,
    val blueGlow: Color,
    val tealPulse: Color,
    val hudBorder: Color,
    val amberAlert: Color,
    val emeraldOnline: Color,
    val crimsonWarn: Color,
    val slateText: Color
)

private val DefaultHudColors = JarvisHudColors(
    voidBackground = VoidBlack,
    panelSurface = HudPanelDark,
    panelElevated = HudPanelElevated,
    cyanGlow = ArcCyan,
    blueGlow = ArcBlue,
    tealPulse = ArcTeal,
    hudBorder = HudBorderCyan,
    amberAlert = HudAmber,
    emeraldOnline = HudEmerald,
    crimsonWarn = HudCrimson,
    slateText = HudSlateText
)

val LocalJarvisHudColors = staticCompositionLocalOf { DefaultHudColors }

private val JarvisDarkColorScheme = darkColorScheme(
    primary = ArcCyan,
    onPrimary = VoidBlack,
    primaryContainer = ArcElectricContainer,
    onPrimaryContainer = HudIceWhite,
    secondary = ArcBlue,
    onSecondary = HudIceWhite,
    secondaryContainer = HudPanelElevated,
    onSecondaryContainer = HudIceWhite,
    tertiary = ArcTeal,
    onTertiary = VoidBlack,
    background = VoidBlack,
    onBackground = HudIceWhite,
    surface = HudObsidian,
    onSurface = HudIceWhite,
    surfaceVariant = HudPanelDark,
    onSurfaceVariant = HudSlateText,
    surfaceContainerLowest = VoidBlack,
    surfaceContainerLow = HudObsidian,
    surfaceContainer = HudPanelDark,
    surfaceContainerHigh = HudPanelElevated,
    surfaceContainerHighest = HudSurfaceBright,
    outline = HudBorderCyan,
    outlineVariant = HudBorderCyan.copy(alpha = 0.45f),
    error = HudCrimson,
    onError = VoidBlack
)

object JarvisTheme {
    val hudColors: JarvisHudColors
        @Composable
        get() = LocalJarvisHudColors.current
}

@Composable
fun JarvisTheme(
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalJarvisHudColors provides DefaultHudColors) {
        MaterialTheme(
            colorScheme = JarvisDarkColorScheme,
            typography = JarvisTypography,
            shapes = JarvisShapes,
            content = content
        )
    }
}
