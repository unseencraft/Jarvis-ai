package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.security.PermissionInspector
import com.example.core.telemetry.DeviceTelemetryMonitor
import com.example.domain.model.AssistantStatus
import com.example.domain.model.DeviceTelemetry
import com.example.domain.model.HudMessage
import com.example.domain.model.HudTab
import com.example.domain.model.JarvisModuleCatalog
import com.example.domain.model.JarvisModuleInfo
import com.example.domain.model.MessageSender
import com.example.domain.model.PermissionAuditItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class JarvisHudUiState(
    val selectedTab: HudTab = HudTab.HUD_CORE,
    val assistantStatus: AssistantStatus = AssistantStatus.IDLE,
    val telemetry: DeviceTelemetry = DeviceTelemetry(),
    val messages: List<HudMessage> = emptyList(),
    val modules: List<JarvisModuleInfo> = JarvisModuleCatalog.modules,
    val selectedModule: JarvisModuleInfo? = null,
    val permissionAudit: List<PermissionAuditItem> = emptyList(),
    val inputDraft: String = "",
    val showClearHistoryDialog: Boolean = false
)

class JarvisHudViewModel(application: Application) : AndroidViewModel(application) {

    private val telemetryMonitor = DeviceTelemetryMonitor(application)
    private val permissionInspector = PermissionInspector(application)
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val _uiState = MutableStateFlow(
        JarvisHudUiState(
            telemetry = telemetryMonitor.snapshot(),
            messages = buildInitialWelcomeMessages(telemetryMonitor.snapshot()),
            permissionAudit = permissionInspector.inspectAll()
        )
    )
    val uiState: StateFlow<JarvisHudUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            telemetryMonitor.observeTelemetry().collect { latestTelemetry ->
                _uiState.update { it.copy(telemetry = latestTelemetry) }
            }
        }
    }

    fun selectTab(tab: HudTab) {
        _uiState.update { it.copy(selectedTab = tab) }
        if (tab == HudTab.SYSTEMS) {
            refreshDiagnostics()
        }
    }

    fun setAssistantStatus(status: AssistantStatus) {
        _uiState.update { it.copy(assistantStatus = status) }
    }

    fun toggleListeningPreview() {
        _uiState.update { current ->
            val next = if (current.assistantStatus == AssistantStatus.LISTENING) {
                AssistantStatus.IDLE
            } else {
                AssistantStatus.LISTENING
            }
            current.copy(assistantStatus = next)
        }
    }

    fun updateInputDraft(value: String) {
        _uiState.update { it.copy(inputDraft = value) }
    }

    fun submitCommand(rawText: String = _uiState.value.inputDraft) {
        val text = rawText.trim()
        if (text.isEmpty()) return

        val nowLabel = timeFormat.format(Date())
        val userMsg = HudMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.USER,
            text = text,
            timestampLabel = nowLabel
        )

        val currentTelemetry = _uiState.value.telemetry
        val replyText = buildStage1Response(text, currentTelemetry)
        val jarvisMsg = HudMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.JARVIS,
            text = replyText,
            timestampLabel = nowLabel,
            tag = "STAGE 1 • LOCAL HUD"
        )

        _uiState.update { state ->
            state.copy(
                inputDraft = if (rawText == state.inputDraft) "" else state.inputDraft,
                assistantStatus = AssistantStatus.SPEAKING,
                messages = state.messages + userMsg + jarvisMsg
            )
        }
    }

    fun openModuleDetails(module: JarvisModuleInfo) {
        _uiState.update { it.copy(selectedModule = module) }
    }

    fun dismissModuleDetails() {
        _uiState.update { it.copy(selectedModule = null) }
    }

    fun refreshDiagnostics() {
        val updatedTelemetry = telemetryMonitor.snapshot()
        val updatedAudit = permissionInspector.inspectAll()
        _uiState.update {
            it.copy(
                telemetry = updatedTelemetry,
                permissionAudit = updatedAudit
            )
        }
    }

    fun requestClearHistoryDialog(show: Boolean) {
        _uiState.update { it.copy(showClearHistoryDialog = show) }
    }

    fun clearConsoleHistory() {
        val currentTelemetry = _uiState.value.telemetry
        _uiState.update {
            it.copy(
                showClearHistoryDialog = false,
                assistantStatus = AssistantStatus.IDLE,
                messages = listOf(
                    HudMessage(
                        id = UUID.randomUUID().toString(),
                        sender = MessageSender.SYSTEM,
                        text = "HUD console history cleared. Battery at ${currentTelemetry.batteryPercent}% (${currentTelemetry.chargeSource}).",
                        timestampLabel = timeFormat.format(Date()),
                        tag = "PRIVACY RESET"
                    )
                )
            )
        }
    }

    private fun buildStage1Response(query: String, telemetry: DeviceTelemetry): String {
        val lower = query.lowercase(Locale.getDefault())
        return when {
            lower.contains("battery") || lower.contains("power") || lower.contains("status") -> {
                val chargingWord = if (telemetry.isCharging) "charging via ${telemetry.chargeSource}" else "on battery"
                val temp = String.format(Locale.getDefault(), "%.1f", telemetry.batteryTempCelsius)
                val availRam = String.format(Locale.getDefault(), "%.2f", telemetry.availableRamGb)
                val totalRam = String.format(Locale.getDefault(), "%.2f", telemetry.totalRamGb)
                "All Stage 1 HUD telemetry systems are nominal. Battery is at ${telemetry.batteryPercent}% ($chargingWord, $temp°C), with $availRam GB / $totalRam GB RAM available on ${telemetry.deviceName} (Android ${telemetry.androidVersion})."
            }

            lower.contains("spec") || lower.contains("hardware") || lower.contains("ram") || lower.contains("phone") -> {
                val availRam = String.format(Locale.getDefault(), "%.2f", telemetry.availableRamGb)
                val totalRam = String.format(Locale.getDefault(), "%.2f", telemetry.totalRamGb)
                "Hardware readout: ${telemetry.deviceName} running Android ${telemetry.androidVersion} (API ${telemetry.sdkInt}). Available memory: $availRam GB of $totalRam GB."
            }

            lower.contains("stage") || lower.contains("gemini") || lower.contains("roadmap") -> {
                "Stage 1 establishes the Android project architecture, live device telemetry, App Check security foundation, and the animated JARVIS HUD. Stage 2 will connect the Gemini AI Brain (Firebase AI Logic) for full Hinglish & English reasoning."
            }

            lower.contains("kya haal") || lower.contains("kaise") || lower.contains("hello") || lower.contains("hey") || lower.contains("hi") -> {
                "Bilkul badhiya, dost! Stage 1 HUD Core online hai aur saare visuals smooth chal rahe hain. Stage 2 mein jab Gemini AI Brain connect hoga, tab hum full natural Hinglish conversations aur smart planning shuru karenge!"
            }

            else -> {
                "Command logged in Stage 1 HUD Console: \"$query\". Visuals and live device telemetry are active now; full Gemini conversational reasoning will activate in Stage 2."
            }
        }
    }

    private fun buildInitialWelcomeMessages(telemetry: DeviceTelemetry): List<HudMessage> {
        val now = timeFormat.format(Date())
        return listOf(
            HudMessage(
                id = "sys_init",
                sender = MessageSender.SYSTEM,
                text = "HUD CORE INITIALIZED • ${telemetry.deviceName.uppercase(Locale.getDefault())} • BATTERY ${telemetry.batteryPercent}%",
                timestampLabel = now,
                tag = "SYSTEM BOOT"
            ),
            HudMessage(
                id = "jarvis_welcome",
                sender = MessageSender.JARVIS,
                text = "Good to see you online! Main hoon JARVIS — Stage 1 HUD interface aur live device telemetry ab ready hai. Tap the Arc Orb to preview voice states, or inspect our 10-module architecture in the Modules tab.",
                timestampLabel = now,
                tag = "MARK I • ONLINE"
            )
        )
    }
}
